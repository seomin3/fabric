from distutils.core import setup

setup(
	name	= 'nester',
	version	= '1.1.0',
	py_modules	= ['nester'],
	author		= 'seomin3',
	author_email	= 'seomin3@icloud.com',
	url		= 'http://seomin.no-ip.info',
	description	= 'A simple printer of nested lists',
)
